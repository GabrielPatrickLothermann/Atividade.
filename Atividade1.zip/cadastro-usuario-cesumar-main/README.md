Cadastro Unicesumar
Este projeto é um sistema de gerenciamento de usuários e categorias utilizando Node.js com Express e MySQL. Ele permite o cadastro, edição, exclusão e visualização de categorias e usuários, além de uma funcionalidade de login.



Tecnologias
Node.js: Ambiente de execução JavaScript.
Express: Framework web para Node.js.
MySQL: Sistema de gerenciamento de banco de dados relacional.
EJS: Engine de template para renderização de páginas HTML.
